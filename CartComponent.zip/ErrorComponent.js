Vue.component('error', {
    props:['error'],
    template:`
    <div>
    <h1> {{ error }}</h1>
    </div>
    `
})